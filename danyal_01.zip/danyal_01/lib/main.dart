import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Bidding Page',
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      home: MaximumBid(),
    );
  }
}

class MaximumBid extends StatefulWidget {
  @override
  _MaximumBidState createState() => _MaximumBidState();
}

class _MaximumBidState extends State<MaximumBid> {

  double _currentBid = 0.0;

  void _increaseBid() {
    setState(() {
      _currentBid += 50.0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Danyal Bidding Page',
          style: TextStyle(color: Colors.yellow), // Set custom color for the title
        ),
        backgroundColor: Colors.teal, // AppBar background color
      ),
      body: Center( // This centers the content both vertically and horizontally
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min, // Adjust to fit content
            children: [
              Text(
                'Your Current Maximum Bid:',
                style: TextStyle(fontSize: 20, color: Colors.deepOrange), // Custom color for text
              ),
              SizedBox(height: 20),
              Text(
                '\$${_currentBid.toStringAsFixed(2)}',
                style: TextStyle(
                  fontSize: 40,
                  fontWeight: FontWeight.bold,

                ),
              ),
              SizedBox(height: 25),
              ElevatedButton(
                onPressed: _increaseBid,
                style: ElevatedButton.styleFrom(

                ),
                child: Text(
                  'Increase Bid by \$50',
                  style: TextStyle(color: Colors.green), // Button text color
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
